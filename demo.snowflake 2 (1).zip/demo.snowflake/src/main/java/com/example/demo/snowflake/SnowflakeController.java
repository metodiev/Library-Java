package com.example.demo.snowflake;

import com.example.demo.snowflake.SnowflakeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SnowflakeController {

    @Autowired
    private SnowflakeService snowflakeService;

    @GetMapping("/call-procedure")
    public String callProcedure() {
        snowflakeService.callStoredProcedure();
        return "Procedure called!";
    }
}