package com.example.demo.snowflake;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class SnowflakeService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void callStoredProcedure() {
        String sql = "CALL my_stored_procedure()";

        jdbcTemplate.execute(sql);  // Executes the procedure
        System.out.println("Procedure called successfully");
    }
}